
/*----------------------------------------------------------------------------
 # BASIC PART FOR LAB 8

*Poll the touchpad every 25ms and calculate the touch distance. 
*The touch distance determines whether a soft key is touched or not.
*If a soft key is touch then a message is sent to a user.
*Basic part of the lab is to create 4 soft keys on the touch pad.

*Two threads are used.
	 1. TouchDetect: Polls the touchpad every 25ms, creates press events.
	 
	 2. TouchConsumes: uses the press events, waits for the events to happen and sends a message to the user according to the softkey pressed.

 *---------------------------------------------------------------------------*/
 
#include "cmsis_os2.h"
#include <MKL25Z4.h>
#include <stdbool.h>
#include "../include/rgb.h"
#include "../include/serialPort.h"
#include "../include/TSI.h"
     
//defining all the soft keys
#define softKey1Flag (1) //leftout
#define softKey2Flag (2) //leftin
#define softKey3Flag (4) //rightin
#define softKey4Flag (8) //rightout


osEventFlagsId_t touchEvtFlags ;  // event flags


/*--------------------------------------------------------------
 *   Thread t_touch
 *      Read touch position periodically  
 *--------------------------------------------------------------*/
osThreadId_t t_touch;      /* id of thread to read touch pad periodically */

// convert unsigned 8-bit to XXX
void uToString(uint8_t a, char* s) {  

    // array of digits
    int digit[3] ;  // [0] least significant
    uint8_t a_dash ;

    // digits
    int ix;
    for (ix = 0 ; ix < 3; ix++) {
        a_dash = a / 10 ;   // 234 --> 23 
        digit[2-ix] = a - (10 * a_dash) ;  // 234 - 230 --> 4
        a = a_dash ;    // 23
    }
    
    // skip leading zero
    ix = 0 ;
    while ( (ix < 2) && (digit[ix] == 0) ) {
        s[ix] = ' ' ;
        ix++ ;
    }
    
      // characters
    while (ix < 3) {
        s[ix] = digit[ix] + '0' ;
        ix++ ;
    }
}

/*--------------------------------------------------------------------------------------------------------------------------------
*TouchDetect polls the position of the finger every 25ms 
*Creates press events(sets events)
*TouchDetect Implements the State machine transition diagram
---------------------------------------------------------------------------------------------------------------------------------*/

//defining the states
#define NONE 0
#define LEFTOUT 1
#define LEFTIN 2
#define RIGHTOUT 3
#define RIGHTIN 4

osThreadId_t t_detect; 

char distStr[] = "dist = XXX" ;
//                01234567890

int SoftkeyState; //state of the soft key
void TouchDetect(void *arg){

    // data buffer
    uint8_t touchDist ; 
    
    // initialise touch sensor
    TSI_init() ;
    
		SoftkeyState = NONE;//initial state of the soft key

    
    while(1) {//endless loop
			
      osDelay(25);//polling at 25ms
      touchDist = readTSIDistance() ;
    
			switch(SoftkeyState){ 
				
				case NONE:
				
					if (3<touchDist && touchDist<9)//if statement checks if the touch distance is between 3 to 9
					{//enter if the condition holds true
						
							osEventFlagsSet(touchEvtFlags, softKey1Flag) ;
							SoftkeyState=LEFTOUT;//update the soft key state
						
					}//end of if statement
					
					else if (13<touchDist && touchDist<19)//else if statement checks if the touch distance is between 13 to 19
					{//enter if the conditon holds true
						
							osEventFlagsSet(touchEvtFlags, softKey2Flag) ;
							SoftkeyState=LEFTIN;//update the soft key state
						
					}//end of else if statement
					
					else if (23<touchDist && touchDist<29)//else if statement checks if the touch distance is between 23 to 29
					{//enter if the condition holds true
						
							osEventFlagsSet(touchEvtFlags, softKey3Flag) ;
							SoftkeyState=RIGHTIN;//update the soft key state
						
					}//end of else if statement
					
					else if (33<touchDist)//else if statement checks if the touch distance is greater than 33
					{//enter if the condition holds true
						
							osEventFlagsSet(touchEvtFlags, softKey4Flag) ;//set the flag for
							SoftkeyState=RIGHTOUT;//update the soft key state
						
					}//end of else if statement
					
				break;
        
					
				case LEFTIN:
					if(touchDist<13 || touchDist>19)//if statement checks if the touch distance is less than 13 OR touch distance is greater than 19
					{//enter if the condition holds true
						
						SoftkeyState=NONE;//update the soft key state
						
					}//end of if statement
				break;
					
				case LEFTOUT:
					if(touchDist<3 || touchDist>9)//if statement checks if the touch distance is less than 3 OR touch distance is greater than 9
					{//enter if the condition holds true
						
						SoftkeyState=NONE;//update the soft key state
						
					}//end of if statement
				break;
					
				case RIGHTIN:
					if(touchDist<23 || touchDist>29)//if statement checks if the touch distance is less than 23 OR touch distance is greater than 29
					{//enter if the condition holds true
						
						SoftkeyState=NONE;//update the soft key state
						
					}//end of if statement
				break;
					
				case RIGHTOUT:
				  if(touchDist<33)//if statement checks if the touch distance is less than 33
					{//enter if the condition holds true

						SoftkeyState=NONE;//update the soft key state
						
					}//end of if statement
				break;
			 
			
			}//End of switch statement
			
			
        
    }//End of while loop


}//End of TouchDetect



/*--------------------------------------------------------------------------------------------------------------------------------
*TouchConsumes uses the press events and waits for them and sends a message to the user according to the softkey pressed
---------------------------------------------------------------------------------------------------------------------------------*/

osThreadId_t t_consumes; 

void TouchConsumes(void *arg){

		uint32_t flags ; // returned by osEventFlagWait
	
    while(1){
			
			//structure declaration
			typedef struct{
			 
				//members or fields of structure
				char *message;
				char *errorMsg;
			
			}SoftKey;

			SoftKey key;//creating a struct variable with name 'key' to access the members of the structure
			
			
			//waits forever for any of the softkey to be pressed
			flags = osEventFlagsWait (touchEvtFlags, softKey1Flag |softKey2Flag | softKey3Flag | softKey4Flag , osFlagsWaitAny, osWaitForever);
		   				
							
			// if the wait is complete then now check which soft key flag caused the wait to be complete
			if(flags & softKey1Flag)//if statement checks if soft key 1(Outer left soft key) caused the wait to complete 
			{//enter if the condition holds true
								
				key.message = "OuterLeft SoftKey Pressed";//message to be sent to the user if outer left soft key is pressed
				sendMsg(key.message, CRLF);//send message to the user
				osEventFlagsClear(touchEvtFlags, softKey1Flag);//clear the flag
								
			}//end of if statement
			else if(flags & softKey2Flag)//else //if statement checks if soft key 2(Inner left soft key) caused the wait to complete 
			{//enter if the condition holds true
								
				key.message = "InnerLeft SoftKey Pressed";//message to be sent to the user if inner left soft key is pressed
				sendMsg(key.message, CRLF);//send message to the user
				osEventFlagsClear(touchEvtFlags, softKey2Flag);//clear the flag
							
			}//end of else if statement
			else if(flags & softKey3Flag)//else if statement checks if soft key 3(Inner Right soft key) caused the wait to complete 
			{//enter if the condition holds true
								
				key.message = "InnerRight SoftKey Pressed";//message to be sent to the user if inner right soft key is pressed
				sendMsg(key.message, CRLF);//send message to the user 
				osEventFlagsClear(touchEvtFlags, softKey3Flag);//clear the flag
							
			}//end of else if statement
			else if(flags & softKey4Flag)//else if statement checks if soft key 4(Outer Right soft key) caused the wait to complete 
			{//enter if the condition holds true
								
				key.message = "OuterRight SoftKey Pressed";//message to be sent to the user if outer right soft key is pressed
				sendMsg(key.message, CRLF);//send message to the user
				osEventFlagsClear(touchEvtFlags, softKey4Flag);//clear the flag
							
			}//end of else if statement
			else if(flags == osFlagsErrorUnknown)//else if statement checks if an error occured
			{//enter if the condition holds true
				
				key.errorMsg = "Error Ocuured";//message to be sent to the user if an error occured
				sendMsg(key.errorMsg, NOLINE);//send message to the user
				
			}//end of else if statement
	
			
		}//End of while loop


}//End of function TouchConsumes


/*----------------------------------------------------------------------------
 * Application main
 *   Initialise I/O
 *   Initialise kernel
 *   Create threads
 *   Start kernel
 *---------------------------------------------------------------------------*/

int main (void) { 
    
    // System Initialization
    SystemCoreClockUpdate();

    //configureGPIOinput();
    init_UART0(115200) ;

    // Initialize CMSIS-RTOS
    osKernelInitialize();
    
    // initialise serial port 
    initSerialPort() ;

    // Initialise RGB LEDs 
    configureRGB() ;

    // Create event flags
    touchEvtFlags = osEventFlagsNew(NULL);
    
    // Create threads
		t_detect = osThreadNew(TouchDetect, NULL, NULL); 
		t_consumes = osThreadNew(TouchConsumes, NULL, NULL); 
 
    osKernelStart();    // Start thread execution - DOES NOT RETURN
    for (;;) {}         // Only executed when an error occurs
}
